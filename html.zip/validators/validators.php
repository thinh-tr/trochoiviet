<?php
// Các kiểm tra về tính hợp lệ của một số thuộc tính đặc biệt
