<?php
// Chứa thông tin trạng thái của admin đang được sử dụng

include $_SERVER["DOCUMENT_ROOT"] . "/entities/admin_info.php";

// Tài khoản admin
$admin_account = null;